import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "AI Voice & Vision Assistant - مساعد الصوت والرؤية الذكي",
  description: "AI assistant with voice and camera input, supporting Arabic and English. مساعد ذكي يدعم الصوت والرؤية بالعربية والإنجليزية.",
  keywords: ["AI", "Voice Assistant", "Vision AI", "Arabic", "English", "صوت", "ذكاء اصطناعي"],
  authors: [{ name: "Z.ai Team" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "AI Voice & Vision Assistant",
    description: "AI assistant with voice and camera input, supporting Arabic and English",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <style>{`
          @font-face {
            font-family: 'Noto Sans Arabic';
            src: url('https://fonts.gstatic.com/s/notosansarabic/v18/NotoNaskhArabic-Regular.woff2') format('woff2');
            font-weight: 400;
            font-style: normal;
            font-display: swap;
          }
          @font-face {
            font-family: 'Noto Sans Arabic';
            src: url('https://fonts.gstatic.com/s/notosansarabic/v18/NotoNaskhArabic-Bold.woff2') format('woff2');
            font-weight: 700;
            font-style: normal;
            font-display: swap;
          }
          [dir="rtl"] {
            font-family: 'Noto Sans Arabic', 'Geist', sans-serif;
          }
        `}</style>
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
