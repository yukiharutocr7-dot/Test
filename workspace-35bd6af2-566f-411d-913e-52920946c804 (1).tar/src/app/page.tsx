'use client'

import { useState, useRef, useEffect, useCallback, useMemo } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Mic,
  Plus,
  Loader2,
  User,
  Send,
  Ear,
  Camera,
  Square,
  Check,
  Copy,
  Bot,
  Settings,
  Sparkles,
  MessageSquare,
  Trash2,
  RotateCcw,
  ThumbsUp,
  ThumbsDown,
  Menu,
  X,
  Code,
  Image as ImageIcon
} from 'lucide-react'
import { toast } from 'sonner'

// Types
interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
  type: 'voice' | 'vision' | 'text'
  timestamp: Date
}

interface ChatSession {
  id: string
  title: string
  messages: Message[]
  createdAt: Date
}

// WAV encoder
function createWavFile(audioData: Float32Array, sampleRate: number): Blob {
  const numChannels = 1
  const bitsPerSample = 16
  const bytesPerSample = bitsPerSample / 8
  const blockAlign = numChannels * bytesPerSample
  const byteRate = sampleRate * blockAlign
  const dataSize = audioData.length * bytesPerSample
  const bufferSize = 44 + dataSize

  const buffer = new ArrayBuffer(bufferSize)
  const view = new DataView(buffer)

  const writeString = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i))
    }
  }

  writeString(0, 'RIFF')
  view.setUint32(4, 36 + dataSize, true)
  writeString(8, 'WAVE')
  writeString(12, 'fmt ')
  view.setUint32(16, 16, true)
  view.setUint16(20, 1, true)
  view.setUint16(22, numChannels, true)
  view.setUint32(24, sampleRate, true)
  view.setUint32(28, byteRate, true)
  view.setUint16(32, blockAlign, true)
  view.setUint16(34, bitsPerSample, true)
  writeString(36, 'data')
  view.setUint32(40, dataSize, true)

  const offset = 44
  for (let i = 0; i < audioData.length; i++) {
    const sample = Math.max(-1, Math.min(1, audioData[i]))
    const intSample = sample < 0 ? sample * 0x8000 : sample * 0x7FFF
    view.setInt16(offset + i * 2, intSample, true)
  }

  return new Blob([buffer], { type: 'audio/wav' })
}

// Format message content with markdown-like parsing
function FormattedContent({ content }: { content: string }) {
  // Parse and format content
  const formatContent = (text: string) => {
    const lines = text.split('\n')
    const elements: JSX.Element[] = []
    let inCodeBlock = false
    let codeContent = ''
    let codeLanguage = ''
    
    lines.forEach((line, index) => {
      // Code block start/end
      if (line.startsWith('```')) {
        if (!inCodeBlock) {
          inCodeBlock = true
          codeLanguage = line.slice(3).trim()
          codeContent = ''
        } else {
          inCodeBlock = false
          elements.push(
            <div key={`code-${index}`} className="my-3 rounded-lg overflow-hidden bg-gray-900 border border-gray-700">
              {codeLanguage && (
                <div className="flex items-center gap-2 px-3 py-1.5 bg-gray-800 text-xs text-gray-400 border-b border-gray-700">
                  <Code className="w-3 h-3" />
                  <span>{codeLanguage}</span>
                </div>
              )}
              <pre className="p-4 text-sm overflow-x-auto">
                <code className="text-gray-300">{codeContent}</code>
              </pre>
            </div>
          )
        }
        return
      }
      
      if (inCodeBlock) {
        codeContent += (codeContent ? '\n' : '') + line
        return
      }
      
      // Headings
      if (line.startsWith('### ')) {
        elements.push(<h3 key={index} className="text-lg font-semibold mt-4 mb-2">{line.slice(4)}</h3>)
        return
      }
      if (line.startsWith('## ')) {
        elements.push(<h2 key={index} className="text-xl font-semibold mt-4 mb-2">{line.slice(3)}</h2>)
        return
      }
      if (line.startsWith('# ')) {
        elements.push(<h1 key={index} className="text-2xl font-bold mt-4 mb-3">{line.slice(2)}</h1>)
        return
      }
      
      // Empty line
      if (!line.trim()) {
        elements.push(<div key={index} className="h-3" />)
        return
      }
      
      // Bullet list
      if (line.startsWith('- ') || line.startsWith('* ')) {
        elements.push(
          <div key={index} className="flex gap-2 my-1">
            <span className="text-gray-400">•</span>
            <span>{formatInline(line.slice(2))}</span>
          </div>
        )
        return
      }
      
      // Numbered list
      const numberedMatch = line.match(/^(\d+)\.\s/)
      if (numberedMatch) {
        elements.push(
          <div key={index} className="flex gap-2 my-1">
            <span className="text-gray-400 min-w-[1.5rem]">{numberedMatch[1]}.</span>
            <span>{formatInline(line.slice(numberedMatch[0].length))}</span>
          </div>
        )
        return
      }
      
      // Regular paragraph
      elements.push(<p key={index} className="my-1 leading-7">{formatInline(line)}</p>)
    })
    
    return elements
  }
  
  // Format inline elements (bold, italic, code)
  const formatInline = (text: string): (string | JSX.Element)[] => {
    const parts: (string | JSX.Element)[] = []
    let remaining = text
    let key = 0
    
    while (remaining) {
      // Bold
      const boldMatch = remaining.match(/\*\*(.+?)\*\*/)
      if (boldMatch) {
        const before = remaining.slice(0, boldMatch.index!)
        if (before) parts.push(before)
        parts.push(<strong key={key++} className="font-semibold">{boldMatch[1]}</strong>)
        remaining = remaining.slice(boldMatch.index! + boldMatch[0].length)
        continue
      }
      
      // Inline code
      const codeMatch = remaining.match(/`(.+?)`/)
      if (codeMatch) {
        const before = remaining.slice(0, codeMatch.index!)
        if (before) parts.push(before)
        parts.push(
          <code key={key++} className="px-1.5 py-0.5 rounded bg-gray-700 text-gray-200 text-sm font-mono">
            {codeMatch[1]}
          </code>
        )
        remaining = remaining.slice(codeMatch.index! + codeMatch[0].length)
        continue
      }
      
      parts.push(remaining)
      break
    }
    
    return parts
  }
  
  return <div className="text-[15px]">{formatContent(content)}</div>
}

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([])
  const [sessions, setSessions] = useState<ChatSession[]>([])
  const [currentSessionId, setCurrentSessionId] = useState<string>('')
  const [isListening, setIsListening] = useState(false)
  const [isSeeing, setIsSeeing] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)
  const [awarenessMode, setAwarenessMode] = useState(false)
  const [input, setInput] = useState('')
  const [sessionId] = useState(() => `session-${Date.now()}`)
  const [isRecording, setIsRecording] = useState(false)
  const [recordingTime, setRecordingTime] = useState(0)
  const [language, setLanguage] = useState<'ar' | 'en'>('ar')
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const audioContextRef = useRef<AudioContext | null>(null)
  const audioStreamRef = useRef<MediaStream | null>(null)
  const videoStreamRef = useRef<MediaStream | null>(null)
  const analyserRef = useRef<AnalyserNode | null>(null)
  const sourceNodeRef = useRef<MediaStreamAudioSourceNode | null>(null)
  const processorRef = useRef<ScriptProcessorNode | null>(null)
  const visionIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const scrollRef = useRef<HTMLDivElement>(null)
  const animationRef = useRef<number | null>(null)
  const awarenessRef = useRef(false)
  const processingRef = useRef(false)
  const audioBufferRef = useRef<Float32Array[]>([])
  const inputRef = useRef<HTMLTextAreaElement>(null)

  const isRTL = language === 'ar'

  const t = useMemo(() => ({
    ar: {
      brand: 'نُور',
      subtitle: 'يسمع ويرى',
      newChat: 'محادثة جديدة',
      placeholder: 'اكتب رسالة...',
      today: 'اليوم',
      listening: 'أستمع...',
      copied: 'تم النسخ',
      you: 'أنت',
      nour: 'نُور',
      greeting: 'كيف يمكنني مساعدتك؟',
      chats: 'المحادثات',
      settings: 'الإعدادات',
      language: 'اللغة',
      clearChat: 'مسح المحادثة'
    },
    en: {
      brand: 'Nour',
      subtitle: 'Hears & Sees',
      newChat: 'New chat',
      placeholder: 'Message...',
      today: 'Today',
      listening: 'Listening...',
      copied: 'Copied!',
      you: 'You',
      nour: 'Nour',
      greeting: 'How can I help you?',
      chats: 'Chats',
      settings: 'Settings',
      language: 'Language',
      clearChat: 'Clear chat'
    }
  })[language], [language])

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages])

  useEffect(() => { awarenessRef.current = awarenessMode }, [awarenessMode])
  useEffect(() => { processingRef.current = isProcessing }, [isProcessing])

  const addMsg = useCallback((role: 'user' | 'assistant', content: string, type: 'voice' | 'vision' | 'text' = 'text') => {
    setMessages(prev => [...prev, { id: `msg-${Date.now()}`, role, content, type, timestamp: new Date() }])
  }, [])

  const chat = useCallback(async (message: string, type: 'voice' | 'vision' | 'text' = 'text') => {
    if (!message.trim()) return
    setIsProcessing(true)
    addMsg('user', message, type)

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          message,
          language,
          systemPrompt: language === 'ar'
            ? `أنت "نور"، مساعد ذكي ودود. ترد بالعربية بشكل طبيعي ومفصل. استخدم التنسيق عند الحاجة.`
            : `You are "Nour", a friendly AI assistant. Respond naturally and with detail. Use formatting when appropriate.`
        })
      })
      const data = await res.json()
      if (data.success && data.response) addMsg('assistant', data.response, 'text')
    } catch (e) {
      console.error(e)
    } finally {
      setIsProcessing(false)
    }
  }, [sessionId, language, addMsg])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (input.trim()) { chat(input); setInput('') }
  }

  const startAudio = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, sampleRate: 16000, channelCount: 1 }
      })
      audioStreamRef.current = stream
      const ctx = new AudioContext({ sampleRate: 16000 })
      audioContextRef.current = ctx
      const source = ctx.createMediaStreamSource(stream)
      sourceNodeRef.current = source
      const analyser = ctx.createAnalyser()
      analyser.fftSize = 256
      analyserRef.current = analyser
      source.connect(analyser)

      const dataArr = new Uint8Array(analyser.frequencyBinCount)
      const updateLvl = () => {
        if (!analyserRef.current || !awarenessRef.current) return
        analyser.getByteFrequencyData(dataArr)
        animationRef.current = requestAnimationFrame(updateLvl)
      }
      updateLvl()
      setIsListening(true)

      const proc = ctx.createScriptProcessor(4096, 1, 1)
      processorRef.current = proc
      let rec = false, startT = 0

      proc.onaudioprocess = (e) => {
        if (!awarenessRef.current) return
        const inputData = e.inputBuffer.getChannelData(0)
        analyser.getByteFrequencyData(dataArr)
        const lvl = dataArr.reduce((a, b) => a + b, 0) / dataArr.length

        if (!rec && lvl > 15 && !processingRef.current) {
          rec = true; startT = Date.now(); audioBufferRef.current = []; setIsRecording(true)
        }
        if (rec) {
          audioBufferRef.current.push(new Float32Array(inputData))
          setRecordingTime(Math.floor((Date.now() - startT) / 1000))
        }
        const dur = Date.now() - startT
        if (rec && (dur >= 5000 || (lvl < 5 && dur > 1500))) {
          rec = false; setIsRecording(false); setRecordingTime(0)
          if (audioBufferRef.current.length > 0 && !processingRef.current) {
            const len = audioBufferRef.current.reduce((a, b) => a + b.length, 0)
            if (len > 16000) {
              const buf = new Float32Array(len)
              let off = 0
              for (const c of audioBufferRef.current) { buf.set(c, off); off += c.length }
              processAudio(createWavFile(buf, 16000))
            }
          }
          audioBufferRef.current = []
        }
      }
      source.connect(proc)
      proc.connect(ctx.destination)
    } catch (e) { console.error(e) }
  }, [])

  const stopAudio = useCallback(() => {
    if (animationRef.current) cancelAnimationFrame(animationRef.current)
    if (processorRef.current) processorRef.current.disconnect()
    if (sourceNodeRef.current) sourceNodeRef.current.disconnect()
    if (audioContextRef.current) audioContextRef.current.close()
    if (audioStreamRef.current) audioStreamRef.current.getTracks().forEach(t => t.stop())
    setIsListening(false); setIsRecording(false)
  }, [])

  const processAudio = async (blob: Blob) => {
    try {
      const reader = new FileReader()
      const b64 = await new Promise<string>((res, rej) => {
        reader.onloadend = () => res((reader.result as string).split(',')[1])
        reader.onerror = rej
        reader.readAsDataURL(blob)
      })
      const res = await fetch('/api/asr', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ audioBase64: b64, format: 'wav' })
      })
      const data = await res.json()
      if (data.success && data.transcription?.trim() && data.transcription.trim() !== '#') {
        chat(data.transcription, 'voice')
      }
    } catch (e) { console.error(e) }
  }

  const startCam = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } })
      videoStreamRef.current = stream
      if (videoRef.current) { videoRef.current.srcObject = stream; await videoRef.current.play(); setIsSeeing(true) }
    } catch (e) { console.error(e) }
  }, [])

  const stopCam = useCallback(() => {
    if (visionIntervalRef.current) clearInterval(visionIntervalRef.current)
    if (videoStreamRef.current) videoStreamRef.current.getTracks().forEach(t => t.stop())
    setIsSeeing(false)
  }, [])

  const analyze = useCallback(async () => {
    if (!videoRef.current || !canvasRef.current || processingRef.current || !isSeeing) return
    const vid = videoRef.current, can = canvasRef.current
    if (vid.readyState < 2) return
    can.width = vid.videoWidth || 640; can.height = vid.videoHeight || 480
    const ctx = can.getContext('2d')
    if (!ctx) return
    ctx.drawImage(vid, 0, 0)
    setIsProcessing(true)
    try {
      const res = await fetch('/api/vision', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64: can.toDataURL('image/jpeg', 0.7), language, question: language === 'ar' ? 'صف ما ترى.' : 'Describe what you see.' })
      })
      const data = await res.json()
      if (data.success && data.analysis) { addMsg('user', '📷', 'vision'); addMsg('assistant', data.analysis, 'text') }
    } catch (e) { console.error(e) } finally { setIsProcessing(false) }
  }, [isSeeing, language, addMsg])

  const toggleAwareness = async () => {
    if (!awarenessMode) {
      setAwarenessMode(true); awarenessRef.current = true; await startAudio()
      setTimeout(async () => { if (awarenessRef.current) await startCam() }, 500)
      visionIntervalRef.current = setInterval(() => { if (!processingRef.current && awarenessRef.current && isSeeing) analyze() }, 20000)
    } else { setAwarenessMode(false); awarenessRef.current = false; stopAudio(); stopCam() }
  }

  const copyText = async (id: string, content: string) => {
    await navigator.clipboard.writeText(content)
    setCopiedId(id)
    setTimeout(() => setCopiedId(null), 2000)
    toast.success(t.copied)
  }

  const startNewChat = () => {
    setMessages([])
    setCurrentSessionId('')
    if (awarenessMode) toggleAwareness()
  }

  useEffect(() => { return () => { awarenessRef.current = false; stopAudio(); stopCam() } }, [stopAudio, stopCam])

  return (
    <div className="h-screen flex bg-black text-white" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Hidden video/canvas for vision */}
      <video ref={videoRef} autoPlay playsInline muted className="hidden" />
      <canvas ref={canvasRef} className="hidden" />

      {/* Sidebar */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.aside
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: 260, opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="flex-shrink-0 h-full bg-[#171717] flex flex-col overflow-hidden"
          >
            {/* New Chat Button */}
            <div className="p-2">
              <button
                onClick={startNewChat}
                className="w-full flex items-center gap-3 px-3 py-3 rounded-lg hover:bg-[#2a2a2a] transition-colors text-sm border border-white/20"
              >
                <Plus className="w-5 h-5" />
                <span>{t.newChat}</span>
              </button>
            </div>

            {/* Chats List */}
            <div className="flex-1 overflow-y-auto px-2">
              <div className="text-xs text-gray-500 px-3 py-2">{t.chats}</div>
              {sessions.length === 0 ? (
                <div className="px-3 py-2 text-sm text-gray-500">{t.today}</div>
              ) : (
                sessions.map((session) => (
                  <button
                    key={session.id}
                    onClick={() => setMessages(session.messages)}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-[#2a2a2a] transition-colors text-sm text-left"
                  >
                    <MessageSquare className="w-4 h-4 text-gray-500" />
                    <span className="truncate">{session.title}</span>
                  </button>
                ))
              )}
            </div>

            {/* Bottom Section */}
            <div className="border-t border-white/10 p-2">
              {/* Language Toggle */}
              <button
                onClick={() => setLanguage(l => l === 'ar' ? 'en' : 'ar')}
                className="w-full flex items-center gap-3 px-3 py-3 rounded-lg hover:bg-[#2a2a2a] transition-colors text-sm"
              >
                <User className="w-5 h-5" />
                <span>{language === 'ar' ? 'English' : 'العربية'}</span>
              </button>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 h-full">
        {/* Top Bar */}
        <header className="flex items-center justify-between px-4 py-2 border-b border-white/5">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 rounded-lg hover:bg-[#2a2a2a] transition-colors"
          >
            {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <h1 className="text-lg font-medium">{t.brand}</h1>

          <button
            onClick={toggleAwareness}
            disabled={isProcessing}
            className={`p-2 rounded-lg transition-colors ${
              awarenessMode ? 'bg-red-500/20 text-red-400' : 'hover:bg-[#2a2a2a]'
            }`}
          >
            {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : awarenessMode ? <Square className="w-5 h-5" /> : <Ear className="w-5 h-5" />}
          </button>
        </header>

        {/* Awareness Status */}
        <AnimatePresence>
          {awarenessMode && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="bg-[#1a1a1a] border-b border-white/5 overflow-hidden"
            >
              <div className="flex items-center justify-center gap-6 py-2 text-xs text-gray-400">
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${isRecording ? 'bg-red-500 animate-pulse' : isListening ? 'bg-green-500' : 'bg-gray-500'}`} />
                  <span>{isRecording ? `${recordingTime}s` : isListening ? 'Hearing' : 'Off'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${isSeeing ? 'bg-green-500' : 'bg-gray-500'}`} />
                  <span>{isSeeing ? 'Vision On' : 'Vision Off'}</span>
                </div>
                {isSeeing && (
                  <button onClick={analyze} disabled={isProcessing} className="flex items-center gap-1 px-2 py-1 bg-[#2a2a2a] rounded hover:bg-[#333] transition-colors">
                    <Camera className="w-3 h-3" />
                    <span>Capture</span>
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto" ref={scrollRef}>
          {messages.length === 0 ? (
            /* Empty State */
            <div className="h-full flex flex-col items-center justify-center px-4">
              <h2 className="text-2xl font-medium text-white mb-8">{t.greeting}</h2>
            </div>
          ) : (
            /* Messages */
            <div className="max-w-3xl mx-auto py-4">
              <AnimatePresence initial={false}>
                {messages.map((msg) => (
                  <motion.div
                    key={msg.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`mb-6 ${msg.role === 'user' ? 'flex justify-end' : ''}`}
                  >
                    {msg.role === 'assistant' ? (
                      /* AI Message - Full Width */
                      <div className="flex gap-4">
                        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[#19c37d] flex items-center justify-center">
                          <Bot className="w-5 h-5 text-white" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium mb-1">{t.nour}</div>
                          <div className="text-gray-200">
                            <FormattedContent content={msg.content} />
                          </div>
                          
                          {/* Action Buttons */}
                          <div className="flex items-center gap-1 mt-3">
                            <button
                              onClick={() => copyText(msg.id, msg.content)}
                              className="p-1.5 rounded hover:bg-[#2a2a2a] transition-colors text-gray-500 hover:text-gray-300"
                            >
                              {copiedId === msg.id ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                            </button>
                            <button className="p-1.5 rounded hover:bg-[#2a2a2a] transition-colors text-gray-500 hover:text-gray-300">
                              <ThumbsUp className="w-4 h-4" />
                            </button>
                            <button className="p-1.5 rounded hover:bg-[#2a2a2a] transition-colors text-gray-500 hover:text-gray-300">
                              <ThumbsDown className="w-4 h-4" />
                            </button>
                            <button className="p-1.5 rounded hover:bg-[#2a2a2a] transition-colors text-gray-500 hover:text-gray-300">
                              <RotateCcw className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ) : (
                      /* User Message - Small Box Right */
                      <div className="max-w-[70%] flex gap-2">
                        <div className="bg-[#2f2f2f] px-4 py-2.5 rounded-2xl">
                          <p className="text-[15px] leading-relaxed">{msg.content}</p>
                        </div>
                        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[#ab68ff] flex items-center justify-center">
                          <User className="w-5 h-5 text-white" />
                        </div>
                      </div>
                    )}
                  </motion.div>
                ))}
              </AnimatePresence>

              {/* Typing Indicator */}
              {isProcessing && (
                <div className="flex gap-4 mb-6">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[#19c37d] flex items-center justify-center">
                    <Bot className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-medium mb-1">{t.nour}</div>
                    <div className="flex items-center gap-1 py-2">
                      <span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                      <span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                      <span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '300ms' }} />
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="px-4 pb-4 pt-2">
          <div className="max-w-3xl mx-auto">
            <form onSubmit={handleSubmit}>
              <div className="flex items-end bg-[#2f2f2f] rounded-2xl px-4 py-2 border border-white/10">
                {/* Text Input */}
                <textarea
                  ref={inputRef}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault()
                      handleSubmit(e)
                    }
                  }}
                  placeholder={t.placeholder}
                  rows={1}
                  className="flex-1 bg-transparent py-2 text-[15px] resize-none focus:outline-none placeholder:text-gray-500 min-h-[24px] max-h-32"
                  style={{ height: 'auto' }}
                />

                {/* Mic Button */}
                <button
                  type="button"
                  onClick={toggleAwareness}
                  disabled={isProcessing}
                  className={`p-2 rounded-full transition-colors flex-shrink-0 ${
                    awarenessMode ? 'text-red-400' : 'text-gray-400 hover:text-white'
                  }`}
                >
                  {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : awarenessMode ? <Square className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                </button>

                {/* Send Button */}
                {input.trim() && (
                  <motion.button
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    type="submit"
                    className="p-2 rounded-full bg-white text-black flex-shrink-0 ml-1"
                  >
                    <Send className="w-5 h-5" />
                  </motion.button>
                )}
              </div>
            </form>

            <p className="text-center text-xs text-gray-600 mt-2">
              {t.brand} · {t.subtitle}
            </p>
          </div>
        </div>
      </main>
    </div>
  )
}
