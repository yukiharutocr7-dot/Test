import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

// Store conversations in memory (use database in production)
const conversations = new Map<string, Array<{ role: string; content: string }>>();

let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

export async function POST(req: NextRequest) {
  try {
    const { sessionId, message, systemPrompt, language = 'ar' } = await req.json();

    if (!message) {
      return NextResponse.json({ error: 'Message is required' }, { status: 400 });
    }

    // Get or create conversation history
    let history = conversations.get(sessionId) || [];

    // Add system prompt if new conversation
    if (history.length === 0) {
      const defaultSystemPrompt = language === 'ar'
        ? 'أنت مساعد ذكي ومفيد. تجيب بشكل واضح ومختصر باللغة العربية.'
        : 'You are a helpful AI assistant. Respond clearly and concisely.';

      history.push({
        role: 'assistant',
        content: systemPrompt || defaultSystemPrompt
      });
    }

    // Add user message
    history.push({
      role: 'user',
      content: message
    });

    const zai = await getZAI();

    // Get completion using SDK
    const completion = await zai.chat.completions.create({
      messages: history,
      thinking: { type: 'disabled' }
    });

    const aiResponse = completion.choices?.[0]?.message?.content;

    if (!aiResponse) {
      throw new Error('No response from AI');
    }

    // Add AI response to history
    history.push({
      role: 'assistant',
      content: aiResponse
    });

    // Keep only last 20 messages to prevent context from getting too long
    if (history.length > 20) {
      history = [history[0], ...history.slice(-19)];
    }

    // Save updated history
    conversations.set(sessionId, history);

    return NextResponse.json({
      success: true,
      response: aiResponse,
      messageCount: history.length - 1
    });
  } catch (error) {
    console.error('Chat API Error:', error);
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to get AI response'
      },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const sessionId = searchParams.get('sessionId');

  if (sessionId) {
    conversations.delete(sessionId);
  }

  return NextResponse.json({ success: true, message: 'Conversation cleared' });
}
