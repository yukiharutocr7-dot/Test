import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

export async function POST(req: NextRequest) {
  try {
    const { imageBase64, question, language = 'en' } = await req.json();

    if (!imageBase64) {
      return NextResponse.json({ error: 'Image data is required' }, { status: 400 });
    }

    const zai = await getZAI();

    // Default question based on language
    const defaultQuestion = language === 'ar'
      ? 'صف هذه الصورة بالتفصيل باللغة العربية.'
      : 'Describe this image in detail.';

    const prompt = question || defaultQuestion;

    // Determine mime type from base64 data
    let imageUrl = imageBase64;
    if (!imageBase64.startsWith('data:')) {
      // Assume JPEG if no data URI prefix
      imageUrl = `data:image/jpeg;base64,${imageBase64}`;
    }

    const response = await zai.chat.completions.createVision({
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'text',
              text: prompt
            },
            {
              type: 'image_url',
              image_url: {
                url: imageUrl
              }
            }
          ]
        }
      ],
      thinking: { type: 'disabled' }
    });

    const analysis = response.choices?.[0]?.message?.content;

    if (!analysis) {
      throw new Error('No analysis returned from vision model');
    }

    return NextResponse.json({
      success: true,
      analysis
    });
  } catch (error) {
    console.error('Vision API Error:', error);
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to analyze image'
      },
      { status: 500 }
    );
  }
}
