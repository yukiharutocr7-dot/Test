import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { audioBase64, format = 'wav' } = body;

    if (!audioBase64) {
      return NextResponse.json({ error: 'Audio data is required' }, { status: 400 });
    }

    // Log audio data size for debugging
    const audioSize = Buffer.byteLength(audioBase64, 'base64');
    console.log('ASR: Received audio, size:', audioSize, 'bytes, format:', format);

    // Validate audio size (min 8KB, max 5MB)
    if (audioSize < 8000) {
      console.log('ASR: Audio too short');
      return NextResponse.json({
        success: false,
        error: 'Audio too short. Please speak for at least 2 seconds.',
        code: 'AUDIO_TOO_SHORT'
      });
    }

    if (audioSize > 5000000) {
      console.log('ASR: Audio too long');
      return NextResponse.json({
        success: false,
        error: 'Audio too long. Maximum 30 seconds allowed.',
        code: 'AUDIO_TOO_LONG'
      });
    }

    const zai = await getZAI();

    console.log('ASR: Calling ASR API...');

    const response = await zai.audio.asr.create({
      file_base64: audioBase64
    });

    console.log('ASR: Transcription result:', response.text?.substring(0, 100) || '(empty)');

    if (response.text && response.text.trim()) {
      return NextResponse.json({
        success: true,
        transcription: response.text
      });
    } else {
      return NextResponse.json({
        success: false,
        error: 'No speech detected',
        code: 'NO_SPEECH'
      });
    }
  } catch (error) {
    console.error('ASR API Error:', error);

    const errorMessage = error instanceof Error ? error.message : 'Failed to transcribe audio';

    // Check if it's a format error
    if (errorMessage.includes('Audio format') || errorMessage.includes('conversion')) {
      return NextResponse.json({
        success: false,
        error: 'Audio format error. Please try again.',
        code: 'FORMAT_ERROR'
      }, { status: 400 });
    }

    return NextResponse.json(
      {
        success: false,
        error: errorMessage
      },
      { status: 500 }
    );
  }
}
